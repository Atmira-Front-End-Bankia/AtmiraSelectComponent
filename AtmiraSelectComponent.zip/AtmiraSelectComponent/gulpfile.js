'use strict';
 
var gulp = require('gulp');
var sass = require('gulp-sass');
var uglify = require('gulp-uglify');
var min = require('gulp-htmlmin');
var clean = require('gulp-clean-css');
var rename = require('gulp-rename');



gulp.task('sass', function () {
    gulp.src('src/sass/*.scss')
    .pipe(sass().on('error', sass.logError))
    .pipe(clean({compatibility: 'ie8'}))
    .pipe(rename('atmiraSelect.min.css'))
    .pipe(gulp.dest('dist'));
});

gulp.task('compress', function(){
    gulp.src('src/js/*.js')
    .pipe(gulp.dest('dist'));
});

gulp.task('minify', function() {
    gulp.src('src/html/*.html')
    .pipe(min({collapseWhitespace: true}))
    .pipe(rename('atmiraSelect.min.html'))
    .pipe(gulp.dest('dist'));
});

gulp.task('default', ['sass','compress','minify']);