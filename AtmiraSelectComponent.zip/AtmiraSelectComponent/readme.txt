//how to use
//inject in angular.module('app', ['atmiraSelect'])
//inject in view.html <at-select placeholder="" list="a" property="name" selected="ver" ></at-select>
//inject <script src="AtmiraSelectComponent/dist/atmiraSelect.js"></script> into index.html 
//inject <link rel="stylesheet" href="AtmiraSelectComponent/dist/atmiraSelect.min.css"> into index.html
placeholder -- string -- to show the placeholder value. -- default set to empty string if you don't want to break everything :)
list -- object -- list of elements to show in the dropdown.
property -- object -- field of object to show.
selected -- string -- save the value in variable to show it in the select box. 